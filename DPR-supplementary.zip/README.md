# DPR supplementary material (EDBT 2027)

This package supplies existing recorded results, the archived training code,
configurations and provenance. It was assembled without new SQL execution or
training. It supports result verification and implementation inspection. Full
training additionally requires the external database and large input assets.

## 1. Verify the package and reported results (Python 3 standard library)

From this directory:
```
python3 verify_package.py
python3 measurements/verify.py
python3 selection/verify_selection.py
```
The first command checks the size and SHA-256 of every declared payload file.
The two existing scripts recompute the forward Full-DPR CP4/CP9 results (32 test
queries, four scored timings each), including ratios, tails and the sensitivity
without 29c_ceb, and reproduce both-direction DPR/pairwise-MIR top-K selections.
They do not train models or connect to PostgreSQL.

## 2. Training implementation

* `code/formal-v17/scripts/run_exp049_limao_small_switch.py`: archived training
  driver used by the full-DPR CAGrad runs. Its SHA-256 is
  f69824b3752489f6b34e4a15aa665293060356a809f4d1e4ded5c3405e9c453b.
* `code/formal-v17/src/strategy/`: DPR, query-level replay, decision-preservation
  loss, CAGrad integration, baseline selection and development-screen modules.
* `code/formal-v17/tests/`: archived method tests; some require training-library
  dependencies, unlike the three commands above.
* `code/LIMAO-final-workload/`: upstream LIMAO/Balsa snapshot, including model,
  training, workload SQL, dependency declarations and its original license.
* `code/analysis/`: original analysis and measurement tools.

Code files are byte-identical to the original single-seed archive. Historical
summary/provenance files inside formal-v17 describe its v16 derivation; the
`RUNNER-PROVENANCE-NOTE.md` distinguishes this from the actual v17 runner.
Earlier baseline/budget variants can bind other frozen runner hashes; do not
assume every historical run used v17. Their provenance identifies the exact
runner; additional historical freezes remain available from the authors.

## 3. Configuration and evidence map

`RUN_INDEX.json` maps original training provenance to workload parameter names,
seed, replay mode, initial-input checksums and source runner hashes. Keep full
paths in `evidence/` when locating the corresponding manifests and analyses.

Adopted full-DPR runs:
* Forward: `dpr-cagrad05-budget20-forward-dev-v1`, seed 5001, A3 -> A4.
* Reverse: `cagrad05-budget20-reverse-confirm-v1`, seed 5101, A4 -> A3.
* Selector configuration comparison:
  `uniform-selection-cagrad05-budget20-forward-ablation-v1`.
* Standard-training comparison: `dpr-budget20-forward-v3`.

Full trajectories have five historical rounds, five incoming rounds and one
return round. Each configuration has its own CP4. The Full-DPR/Uniform+keep
comparison shares the initial model and training schedule, but not a common
CP4 or identical recorded latency labels. Developer screens using a shared CP4
are limited development evidence. Many configurations/iterations/reloaded
measurements do not constitute independent seed repetitions.

## 4. Original execution environment and training preparation

`environment/README.md` documents the observed Python 3.8.20/PostgreSQL 12.5/
pg_hint_plan 1.3.7 environment and points to original execution snapshots.
The upstream requirements are declarations, not a newly validated lockfile.
This package has not been tested by restoring a clean Linux training instance.

Training is not a one-command operation using only this ZIP. The driver accepts
`--repo`, `--output-dir`, `--initial-policy-a`, `--initial-policy-b`,
`--sim-data-a`, `--sim-feature-a`, `--sim-checkpoint-a`, workload parameters,
`--seed`, `--replay-mode`, `--bounded-selection-json`, `--bounded-method`,
`--replay-budget` and decision-preservation flags. Use the archived provenance
to restore and checksum the required initial inputs and select the workload
parameter names. Do not run with defaults and assume it matches the paper.
Install the compatible LIMAO/Balsa dependencies and PostgreSQL/pg_hint_plan,
load the IMDb database, restore the required simulator and policy inputs, and
substitute local paths for the original machine paths. Full DPR uses the
bounded-query-replay mode, DPR selection, K=20 and CAGrad (c=0.5).

## 5. Excluded large assets

Model checkpoints, simulator feature/data inputs, initial-policy binaries, the
IMDb database and exhaustive logs are not included. The original full package
contains about 32 GB of expanded material and is retained by the authors;
required external assets and extra historical freezes are available on request,
subject to the original data/source distribution terms. Their recorded sizes
and hashes are in the supplied run provenance. This ZIP is not a self-contained
database-and-training image. Original upstream copyright/license notices are
preserved. See `PACKAGE_MANIFEST.json` for file-level provenance and integrity.
