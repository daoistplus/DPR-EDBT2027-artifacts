SELECT COUNT(*) FROM title as t,
kind_type as kt,
info_type as it1,
movie_info as mi1,
movie_info as mi2,
info_type as it2,
cast_info as ci,
role_type as rt,
name as n
WHERE
t.id = ci.movie_id
AND t.id = mi1.movie_id
AND t.id = mi2.movie_id
AND mi1.movie_id = mi2.movie_id
AND mi1.info_type_id = it1.id
AND mi2.info_type_id = it2.id
AND (it1.id in ('6'))
AND (it2.id in ('3'))
AND t.kind_id = kt.id
AND ci.person_id = n.id
AND ci.role_id = rt.id
AND (mi1.info IN ('Dolby SR','Dolby','Mono','Stereo','Ultra Stereo'))
AND (mi2.info IN ('Adventure','Biography','Comedy','Fantasy','Horror','War','Western'))
AND (kt.kind in ('episode','movie','tv movie','tv series','video game','video movie'))
AND (rt.role in ('actor','director','editor','miscellaneous crew','production designer'))
AND (n.gender IS NULL)
AND (t.production_year <= 1990)
AND (t.production_year >= 1950)
AND (t.title in ('(#1.19)','(#1.242)','(#1.480)','(#1.955)','(#1.968)','(#3.5)','(#5.11)','(#8.8)','Absolute Beginners','Act of Vengeance','All Night Long','Baburugamu kuraishisu','Balance of Power','Bells Are Ringing','Brookside','Candida','Casualty','Childrens Ward','Dead Wrong','Deadly Reunion','Delivery Boys','Fire Down Below','Glitch!','Happy Returns','Heat','La trampa','Licensed to Kill','Mightier Than the Sword','Monkey Business','Mother, Mother','Neighbours','Oliver Twist','Poetic Justice','Rough Justice','Suspicious Minds','The Aftermath','The Best of Enemies','The Deserter','The Gunman','The New World','The Sniper','Too Hot to Handle','Too Many Cooks','V'))
